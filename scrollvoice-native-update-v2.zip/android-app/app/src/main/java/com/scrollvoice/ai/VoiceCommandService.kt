package com.scrollvoice.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class VoiceCommandService : Service(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sessionActive = false
    private var paused = false
    private var autoMode = false
    private var restartPending = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startListeningSession()
            ACTION_STOP -> stopSession()
            ACTION_PAUSE -> { paused = true; updateNotification("Dijeda — ucapkan Lanjut atau Matikan") }
            ACTION_RESUME -> { paused = false; updateNotification("Mendengarkan perintah") }
            ACTION_TOGGLE_AUTO -> { autoMode = !autoMode; updateNotification(if (autoMode) "Mode Otomatis aktif" else "Mode Otomatis nonaktif") }
        }
        return START_NOT_STICKY
    }

    private fun startListeningSession() {
        if (sessionActive) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            stopWithNotice("Pengenalan suara offline memerlukan Android 12 atau lebih baru.")
            return
        }
        startForeground(NOTIFICATION_ID, buildNotification("Memeriksa model suara offline…"))
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            stopWithNotice("Izin mikrofon belum diberikan.")
            return
        }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            stopWithNotice("Pengenalan suara offline tidak tersedia di perangkat ini. Tidak beralih ke layanan online.")
            return
        }
        try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            sessionActive = true
            paused = false
            isRunning = true
            isPaused = false
            updateNotification("Mendengarkan perintah offline")
            beginRecognition()
        } catch (_: Exception) {
            stopWithNotice("Tidak dapat memulai pengenalan suara offline.")
        }
    }

    private fun beginRecognition() {
        if (!sessionActive || recognizer == null || restartPending) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { scheduleRestart(900) }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onResults(results: Bundle?) {
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
        val command = phrases.mapIndexedNotNull { index, phrase ->
            val normalized = normalize(phrase)
            val score = scores?.getOrNull(index) ?: -1f
            val confidenceAccepted = score < 0f || score >= MIN_CONFIDENCE
            if (normalized in ALLOWED_COMMANDS && confidenceAccepted) normalized else null
        }.firstOrNull()
        if (command != null) handleCommand(command)
        scheduleRestart(450)
    }

    override fun onError(error: Int) {
        if (!sessionActive) return
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            stopWithNotice("Izin mikrofon tidak tersedia.")
            return
        }
        val delay = when (error) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> 1400L
            else -> 650L
        }
        scheduleRestart(delay)
    }

    private fun handleCommand(command: String) {
        if (paused && command != "lanjut" && command != "matikan") return
        when (command) {
            "scroll" -> {
                ScrollVoiceAccessibilityService.instance?.scrollDown()
                updateNotification("Perintah Scroll diterima")
            }
            "balik" -> {
                ScrollVoiceAccessibilityService.instance?.scrollUp()
                updateNotification("Perintah Balik diterima")
            }
            "stop" -> {
                paused = true
                isPaused = true
                updateNotification("Dijeda — ucapkan Lanjut atau Matikan")
            }
            "lanjut" -> {
                paused = false
                isPaused = false
                updateNotification("Mendengarkan perintah offline")
            }
            "otomatis" -> {
                autoMode = !autoMode
                updateNotification(if (autoMode) "Mode Otomatis aktif" else "Mode Otomatis nonaktif")
            }
            "matikan" -> stopSession()
        }
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .trim()
        .replace(Regex("""^[\p{Punct}\s]+|[\p{Punct}\s]+$"""), "")
        .trim()

    private fun scheduleRestart(delay: Long) {
        if (!sessionActive || restartPending) return
        restartPending = true
        handler.postDelayed({
            restartPending = false
            if (sessionActive) beginRecognition()
        }, delay)
    }

    @Suppress("DEPRECATION")
    private fun stopSession() {
        sessionActive = false
        paused = false
        autoMode = false
        restartPending = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        isRunning = false
        isPaused = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun stopWithNotice(message: String) {
        sessionActive = false
        isRunning = false
        isPaused = false
        updateNotification(message)
        handler.postDelayed({
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
            stopSelf()
        }, 3500)
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun buildNotification(message: String): Notification {
        val channelId = "scrollvoice_microphone"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "ScrollVoice microphone", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows when ScrollVoice is listening for voice commands"
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openApp = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ScrollVoice AI")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(sessionActive)
            .build()
    }

    override fun onDestroy() {
        sessionActive = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        isRunning = false
        isPaused = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.scrollvoice.ai.action.START"
        const val ACTION_STOP = "com.scrollvoice.ai.action.STOP"
        const val ACTION_PAUSE = "com.scrollvoice.ai.action.PAUSE"
        const val ACTION_RESUME = "com.scrollvoice.ai.action.RESUME"
        const val ACTION_TOGGLE_AUTO = "com.scrollvoice.ai.action.TOGGLE_AUTO"
        private const val NOTIFICATION_ID = 7101
        private const val MIN_CONFIDENCE = 0.65f
        private val ALLOWED_COMMANDS = setOf("scroll", "balik", "stop", "lanjut", "otomatis", "matikan")
        @Volatile var isRunning: Boolean = false
        @Volatile var isPaused: Boolean = false
    }
}
