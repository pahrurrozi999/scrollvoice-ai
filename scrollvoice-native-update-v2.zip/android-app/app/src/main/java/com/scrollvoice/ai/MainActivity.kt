package com.scrollvoice.ai

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 29)
    private val card = Color.rgb(21, 28, 49)
    private val white = Color.rgb(245, 247, 255)
    private val muted = Color.rgb(155, 166, 190)
    private val cyan = Color.rgb(0, 220, 235)
    private val purple = Color.rgb(151, 105, 255)

    private lateinit var statusTitle: TextView
    private lateinit var statusCaption: TextView
    private lateinit var accessStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::accessStatus.isInitialized) refreshAccessStatus()
        if (::statusTitle.isInitialized) {
            if (VoiceCommandService.isRunning) {
                statusTitle.text = if (VoiceCommandService.isPaused) "Perintah dijeda" else "Mendengarkan perintah"
                statusCaption.text = "Layanan suara berjalan. Kamu dapat berpindah ke aplikasi video."
            } else {
                statusTitle.text = "Mikrofon belum aktif"
                statusCaption.text = "Tekan Mulai Mendengarkan untuk memulai."
            }
        }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("◉", 32f, cyan, true))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        brand.addView(text("ScrollVoice AI", 21f, white, true))
        brand.addView(text("KONTROL SUARA ANDROID", 10f, muted, true))
        header.addView(brand)
        header.addView(android.view.View(this), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(text("● NATIVE", 10f, cyan, true))
        content.addView(header)
        content.addView(space(28))
        content.addView(text("Kendalikan video", 27f, white, true))
        content.addView(text("cukup dengan suara.", 27f, white, true))
        content.addView(space(8))
        content.addView(text("Enam perintah bahasa Indonesia. Hanya kata yang cocok persis yang diproses.", 13f, muted))
        content.addView(space(22))

        val micCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = rounded(card, 24)
        }
        micCard.addView(text("◉", 42f, cyan, true).apply { gravity = Gravity.CENTER })
        micCard.addView(space(10))
        micCard.addView(text("STATUS MIKROFON", 11f, cyan, true))
        micCard.addView(space(7))
        statusTitle = text("Mikrofon belum aktif", 19f, white, true)
        statusCaption = text("Tekan Mulai Mendengarkan untuk memulai.", 12f, muted)
        micCard.addView(statusTitle)
        micCard.addView(space(5))
        micCard.addView(statusCaption)
        content.addView(micCard)
        content.addView(space(14))

        val startButton = actionButton("Mulai Mendengarkan", cyan, bg) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            } else {
                startVoiceService()
            }
        }
        content.addView(startButton)
        content.addView(space(9))
        content.addView(actionButton("Matikan Mikrofon", Color.rgb(55, 63, 85), white) {
            sendServiceAction(VoiceCommandService.ACTION_STOP)
            statusTitle.text = "Mikrofon tidak aktif"
            statusCaption.text = "Sesi suara sudah dihentikan."
        })

        content.addView(space(20))
        val accessCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.rgb(25, 34, 58), 18)
        }
        accessCard.addView(text("IZIN KONTROL SCROLL", 11f, cyan, true))
        accessCard.addView(space(7))
        accessStatus = text("Memeriksa status Accessibility…", 13f, white)
        accessCard.addView(accessStatus)
        accessCard.addView(space(12))
        accessCard.addView(actionButton("Buka Pengaturan Accessibility", purple, white) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(accessCard)
        content.addView(space(24))
        content.addView(text("ENAM PERINTAH SUARA", 13f, white, true))
        content.addView(space(12))

        val commands = listOf(
            Triple("↓", "Scroll", "Gulir ke video berikutnya"),
            Triple("↑", "Balik", "Gulir ke arah sebelumnya"),
            Triple("Ⅱ", "Stop", "Jeda pemrosesan perintah"),
            Triple("▶", "Lanjut", "Lanjutkan pemrosesan perintah"),
            Triple("↻", "Otomatis", "Aktifkan atau nonaktifkan mode otomatis"),
            Triple("⏻", "Matikan", "Akhiri sesi mikrofon")
        )
        val colors = listOf(cyan, purple, Color.rgb(255, 174, 70), Color.rgb(70, 210, 150), Color.rgb(90, 160, 255), Color.rgb(255, 100, 120))
        commands.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(card, 16)
            }
            row.addView(text(item.first, 24f, colors[index], true).apply {
                gravity = Gravity.CENTER
                background = rounded(Color.rgb(34, 42, 67), 12)
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            })
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(13), 0, 0, 0)
            }
            labels.addView(text(item.second, 16f, white, true))
            labels.addView(space(3))
            labels.addView(text(item.third, 11f, muted))
            row.addView(labels)
            content.addView(row)
            content.addView(space(9))
        }
        content.addView(space(10))
        content.addView(text("Privasi: aplikasi memakai pengenalan suara di perangkat bila tersedia. Tidak ada izin internet di aplikasi ini. Jika pengenalan offline tidak tersedia, aplikasi tidak akan beralih diam-diam ke layanan online.", 11f, muted))
        content.addView(space(16))
        content.addView(text("ScrollVoice AI • Versi 1.1", 11f, muted).apply { gravity = Gravity.CENTER })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        refreshAccessStatus()
    }

    private fun startVoiceService() {
        if (!isAccessibilityEnabled()) {
            statusTitle.text = "Aktifkan Accessibility dahulu"
            statusCaption.text = "Buka pengaturan di bawah agar Scroll dan Balik dapat bekerja di aplikasi lain."
            return
        }
        val intent = Intent(this, VoiceCommandService::class.java).setAction(VoiceCommandService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        statusTitle.text = "Menyiapkan pengenalan suara"
        statusCaption.text = "Memeriksa dukungan pengenalan offline bahasa Indonesia…"
    }

    private fun sendServiceAction(action: String) {
        startService(Intent(this, VoiceCommandService::class.java).setAction(action))
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = "$packageName/${ScrollVoiceAccessibilityService::class.java.name}"
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.id == expected || it.resolveInfo.serviceInfo.name == ScrollVoiceAccessibilityService::class.java.name }
    }

    private fun refreshAccessStatus() {
        if (!::accessStatus.isInitialized) return
        accessStatus.text = if (isAccessibilityEnabled()) {
            "✓ Accessibility aktif. Gerakan scroll dapat dikirim ke aplikasi lain."
        } else {
            "Belum aktif. Izin ini diperlukan hanya untuk mengirim gerakan scroll; aplikasi tidak membaca isi layar."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoiceService()
            else {
                statusTitle.text = "Izin mikrofon belum diberikan"
                statusCaption.text = "Mikrofon tidak digunakan sampai kamu memberi izin."
            }
        }
    }

    private fun actionButton(label: String, color: Int, textColor: Int, action: () -> Unit): TextView {
        return text(label, 14f, textColor, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(color, 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_MIC = 501 }
}
