ScrollVoice AI — patch native v3

Perubahan tunggal: VoiceCommandService.kt
- Otomatis melakukan satu scroll turun setiap 10 detik.
- Stop menjeda auto-scroll.
- Lanjut melanjutkan auto-scroll jika mode Otomatis masih aktif.
- Ucapkan Otomatis lagi untuk mematikan mode otomatis.
- Matikan menghentikan sesi dan auto-scroll.
- Tetap memakai pengenalan suara offline dan enam perintah persis yang sudah ada.

Pemasangan di Codespaces (dari root repository):
1. Ekstrak ZIP ini.
2. Salin file android-app/app/src/main/java/com/scrollvoice/ai/VoiceCommandService.kt dari ZIP ke lokasi yang sama di proyek utama, menimpa file lama.
3. Jangan menimpa file lain.
4. Setelah disalin, jalankan build melalui GitHub Actions seperti sebelumnya.

Catatan: Interval 10 detik dihitung setelah mode Otomatis diaktifkan/dilanjutkan. Scroll memerlukan Accessibility Service aktif.
